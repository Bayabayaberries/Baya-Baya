const { catalog, findProduct, formatCOP } = require('./catalog');
const { getSession, saveSession, resetSession } = require('./session');
const { sendText, sendButtons, sendList } = require('./whatsapp');
const { createPaymentLink } = require('./wompi');

async function showMainMenu(to) {
  await sendButtons(to, '¡Hola! 👋 Tenemos dos marcas para ti:\n\n🫐 *Baya Baya* — arándanos frescos\n🍯 *Oko* — miel pura\n\n¿Qué quieres pedir hoy?', [
    { id: 'brand_arandanos', title: '🫐 Arándanos' },
    { id: 'brand_miel', title: '🍯 Miel' },
    { id: 'menu_carrito', title: 'Ver mi carrito' },
  ]);
}

async function showCatalog(to, categoryKey) {
  // Si viene un categoryKey (arandanos/miel), mostramos solo esa marca.
  // Si no viene, mostramos todo (por ejemplo cuando escriben "catálogo" directamente).
  const categoriesToShow = categoryKey ? { [categoryKey]: catalog[categoryKey] } : catalog;
  const sections = Object.values(categoriesToShow).map((category) => ({
    title: category.label,
    rows: category.items.map((item) => ({
      id: `add_${item.id}`,
      title: item.name,
      description: formatCOP(item.price),
    })),
  }));
  await sendList(to, 'Elige el producto que quieres agregar a tu pedido 👇', 'Ver productos', sections);
}

function cartTotal(cart) {
  return Object.entries(cart).reduce((sum, [id, qty]) => {
    const p = findProduct(id);
    return sum + (p ? p.price * qty : 0);
  }, 0);
}

async function showCart(to, session) {
  const entries = Object.entries(session.cart);
  if (entries.length === 0) {
    await sendText(to, 'Tu carrito está vacío todavía. Escribe *catálogo* para ver los productos.');
    return;
  }
  let text = '🛒 *Tu pedido hasta ahora:*\n\n';
  for (const [id, qty] of entries) {
    const p = findProduct(id);
    text += `• ${p.name} x${qty} — ${formatCOP(p.price * qty)}\n`;
  }
  text += `\n*Total: ${formatCOP(cartTotal(session.cart))}*`;
  await sendText(to, text);
  await sendButtons(to, '¿Qué quieres hacer?', [
    { id: 'menu_catalogo', title: 'Agregar más' },
    { id: 'checkout', title: 'Finalizar pedido' },
    { id: 'vaciar_carrito', title: 'Vaciar carrito' },
  ]);
}

async function handleIncomingMessage(from, message) {
  const session = getSession(from);
  const text = (message.text?.body || '').trim().toLowerCase();
  const buttonId = message.interactive?.button_reply?.id || message.interactive?.list_reply?.id || null;

  // Meta dispara este tipo de mensaje cuando alguien abre el chat por
  // primera vez y aún no ha escrito nada (ahí es cuando ve los ice breakers).
  if (message.type === 'request_welcome') {
    resetSession(from);
    return showMainMenu(from);
  }

  // Comandos globales, funcionan en cualquier momento
  if (text === 'hola' || text === 'menu' || text === 'menú') {
    resetSession(from);
    return showMainMenu(from);
  }

  // Ice breakers: los mensajes que aparecen la primera vez que alguien
  // abre el chat. Al tocarlos, WhatsApp los manda como texto normal,
  // por eso los detectamos comparando el texto exacto.
  if (text.includes('arándanos de baya baya') || text.includes('arandanos de baya baya')) {
    session.step = 'choosing_category';
    saveSession(from, session);
    return showCatalog(from, 'arandanos');
  }
  if (text.includes('miel de oko')) {
    session.step = 'choosing_category';
    saveSession(from, session);
    return showCatalog(from, 'miel');
  }

  // Botones del menú principal, ya eligiendo marca
  if (buttonId === 'brand_arandanos') {
    session.step = 'choosing_category';
    saveSession(from, session);
    return showCatalog(from, 'arandanos');
  }
  if (buttonId === 'brand_miel') {
    session.step = 'choosing_category';
    saveSession(from, session);
    return showCatalog(from, 'miel');
  }

  if (text === 'catálogo' || text === 'catalogo' || buttonId === 'menu_catalogo') {
    session.step = 'choosing_category';
    saveSession(from, session);
    return showCatalog(from);
  }
  if (text === 'carrito' || buttonId === 'menu_carrito') {
    return showCart(from, session);
  }
  if (buttonId === 'menu_asesor') {
    await sendText(from, 'Listo, en un momento te escribe alguien de nuestro equipo por este mismo chat 🙌');
    return;
  }
  if (buttonId === 'vaciar_carrito') {
    resetSession(from);
    await sendText(from, 'Vaciamos tu carrito. Escribe *catálogo* para empezar de nuevo.');
    return;
  }

  // Agregar producto desde la lista del catálogo
  if (buttonId && buttonId.startsWith('add_')) {
    const productId = buttonId.replace('add_', '');
    const product = findProduct(productId);
    if (!product) return sendText(from, 'No encontré ese producto, intenta de nuevo con *catálogo*.');
    session.pendingProductId = productId;
    session.step = 'choosing_qty';
    saveSession(from, session);
    return sendText(from, `¿Cuántas unidades de *${product.name}* quieres? (responde solo con el número)`);
  }

  // Esperando la cantidad
  if (session.step === 'choosing_qty') {
    const qty = parseInt(text, 10);
    if (!qty || qty <= 0) {
      return sendText(from, 'Por favor responde solo con un número, por ejemplo: 2');
    }
    session.cart[session.pendingProductId] = (session.cart[session.pendingProductId] || 0) + qty;
    session.pendingProductId = null;
    session.step = 'menu';
    saveSession(from, session);
    await sendText(from, '¡Agregado! ✅');
    return showCart(from, session);
  }

  // Finalizar pedido → pedir dirección → generar link de pago
  if (buttonId === 'checkout') {
    if (Object.keys(session.cart).length === 0) {
      return sendText(from, 'Tu carrito está vacío. Escribe *catálogo* para agregar productos.');
    }
    session.step = 'awaiting_address';
    saveSession(from, session);
    return sendText(from, '📍 Perfecto, ¿cuál es la dirección de entrega? (barrio, calle/carrera, ciudad)');
  }

  if (session.step === 'awaiting_address') {
    session.address = message.text?.body || '';
    saveSession(from, session);

    const total = cartTotal(session.cart);
    await sendText(from, `Gracias, ya casi terminamos. Total a pagar: *${formatCOP(total)}*\nGenerando tu link de pago... ⏳`);

    try {
      const paymentUrl = await createPaymentLink({
        amountInCents: total * 100,
        reference: `pedido-${from}-${Date.now()}`,
        customerPhone: from,
      });
      await sendText(from, `Aquí está tu link de pago seguro (Wompi) 👇\n${paymentUrl}\n\nApenas se confirme el pago, preparamos tu pedido para *${session.address}*.`);
    } catch (err) {
      console.error('Error generando link de Wompi:', err);
      await sendText(from, 'Tuvimos un problema generando el link de pago automático. En un momento un asesor te contacta para coordinar el pago 🙏');
    }

    resetSession(from);
    return;
  }

  // Si no coincide con nada conocido, mostramos el menú
  return showMainMenu(from);
}

module.exports = { handleIncomingMessage };
